import pickle
import pyperclip
import smtplib
from email.message import EmailMessage
import random
from time import sleep
import cv2
from datacollect import collect
from training import trainer
import sys

with open('D:\\Abhirup. Arduino. CC\\PASSWORD MANEGER\\s_gmail.txt', 'r') as fr:
    s_gmail = fr.read()

with open('D:\\Abhirup. Arduino. CC\\PASSWORD MANEGER\\s_g_pass.txt', 'r') as fa:
    s_g_gmail = fa.read()

name = []

def send_email(receiver, subject, message):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(s_gmail, s_g_gmail)
    email = EmailMessage()
    email['From'] = s_gmail
    email['To'] = receiver
    email['Subject'] = subject
    email.set_content(message)
    server.send_message(email)

def attach_email(receiver, subject, attach, mtype, stype, fname):
    msg = EmailMessage()

    msg['Subject'] = subject
    msg['From'] = 'abhiruprudra@gmail.com'
    msg['To'] = receiver

    msg.add_attachment(attach,maintype=mtype,subtype=stype,filename=fname)

    with smtplib.SMTP_SSL('smtp.gmail.com',465) as server:
        server = smtplib.SMTP_SSL('smtp.gmail.com',465)
        server.login(s_gmail,s_g_gmail)
        server.send_message(msg)

def get_ran():
    text = str(random.randint(100000, 999999))
    return text

def collectphotos(id, name1):
    with open("name.txt", "br") as readfile:
        name = pickle.load(readfile)

    name.append(name1)

    with open("name.txt", "bw") as writefile:
        name = pickle.dump(name, writefile, protocol=2)
        
    collect(id)
    # collectphotos(2, "abhirup")

def trainphotos():
    trainer()

def recognize(name):
    video=cv2.VideoCapture(0)

    facedetect = cv2.CascadeClassifier("data\\haarcascade_frontalface_default.xml")

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read("data\\Trainer.yml")

    # name = ["", "ABHIRUP RUDRA"]

    flag = 0
    i = 0
    while True:
        ret,frame=video.read()
        gray=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = facedetect.detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            serial, conf = recognizer.predict(gray[y:y+h, x:x+w])
            if conf > 70:
                cv2.putText(frame, name[serial], (x,y-40), cv2.FONT_HERSHEY_COMPLEX, 1, (50,50,255), 3)
                cv2.rectangle(frame, (x,y), (x+w, y+h), (50,50,255), 3)
                flag = serial
            else:
                cv2.putText(frame, "UNKNOWN", (x,y-40), cv2.FONT_HERSHEY_COMPLEX, 1, (50,50,255), 3)
                cv2.rectangle(frame, (x,y), (x+w, y+h), (50,50,255), 3)
                flag = 0
                
        cv2.imshow("Frame",frame)

        i+=1
        # if i>=200:
        #     break

        k=cv2.waitKey(1)

        if k == 13 or i >=200:
            break

    video.release()
    cv2.destroyAllWindows()
    return flag


def main():
    dictionary = []
    ch = input("Are you a new user (y/n) : ").lstrip().lower()[0]

    if ch == "y":

        with open("name.txt", "br") as readfile:
            name = pickle.load(readfile)

        id2 = int(len(name)) # int(input("Enter ID : "))
        print(f"Your ID : {id2}")
        name2 = input("Enter Name : ")
        email = input("Enter your full email address : ")

        collectphotos(id2, name2)
        trainphotos()
        with open("email.txt", "br") as em:
            email_dict = pickle.load(em)

        email_dict[name2] = email

        with open("email.txt", "bw") as writefile:
            email_dict = pickle.dump(email_dict, writefile, protocol=2)

        with open("pass.txt", "br") as file:
            store_pass = pickle.load(file)

        password1 = input("Enter a password for your account : ")
        store_pass[name2] = password1

        with open("pass.txt", "bw") as writefile:
            store_pass = pickle.dump(store_pass, writefile, protocol=2)

        m = {"":""}

        with open("account\\"+(name2.lower()+".txt"), "bw") as blank:
            m = pickle.dump(m, blank, protocol=2)


    with open("name.txt", "br") as readfile:
        name = pickle.load(readfile)

    n = recognize(name)

    if n!=0:
        print(f"Hi {name[n].capitalize().split(' ')[0]}.")

        password2 = input("Please enter the password : ")

        with open("pass.txt", "br") as file:
            store_pass = pickle.load(file)

        if store_pass[name[n]] == password2:

            while True:
                code = get_ran()
                msg = f"The Login Code is --> {code}"

                with open("email.txt", "br") as file2:
                    email_dict = pickle.load(file2)
                
                send_email(email_dict[name[n]],"LOGIN CODE",msg)

                codeinput = input("\nEnter the code sent to the registered gmail for confirmation : ")

                while True:
                    if codeinput == code:

                        conf = input("""\n1 - to know your saved password \n2 - to save your password \nexit/stop - to stop program \nEnter your choice (1/2) : """)

                        if "2" in conf:
                            account = input("\nEnter the account name : ").lower().strip()
                            acc_pass = input("Enter the account password : ")

                            confirmation = input("\nWould you like to save it (y/n) : ").lstrip().lower()[0]

                            if "y" in confirmation:

                                with open("account\\"+(name[n].lower()+".txt"), "br") as file:
                                    dictionary = pickle.load(file)

                                dictionary[account] = acc_pass

                                with open("account\\"+(name[n].lower()+".txt"), "bw") as readfile:
                                    dictionary = pickle.dump(dictionary, readfile, protocol=2)

                                print(f"Done! your {account.capitalize()}'s password has been saved.")
                                
                            else:
                                    print("\nYour data has not been saved.......")
                            
                        if "1" in conf:
                            email1 = input("\nWhich account's password you want to know : ").lower().strip()

                            with open("account\\"+(name[n].lower()+".txt"), "br") as file:
                                dictionary = pickle.load(file)
                                
                            if email1 in dictionary:
                                print(f"Your {email1}'s password is copied!!")
                                pyperclip.copy(dictionary[email1])

                            else:
                                print("Password for this account is not saved.")
                            
                        elif "stop" in conf or "exit" in conf:
                            print("Thanks for visiting.\n\nCome again soon.")
                            sleep(6)
                            sys.exit("Stopping the program...")
                        
                        else:
                            print("Entered wrong choice. Try again!")

                    else:
                        print("\nThe code entered by you is wrong.\n\n")
                        sleep(6)
                        break

        else:
            ask = input("\nHave you forgotten your password? (y/n) : ").lstrip().lower()[0]

            if ask == "y":
                code2 = get_ran()
                msg = f"The Password Reset code is --> {code2}"

                with open("email.txt", "br") as file2:
                    email_dict = pickle.load(file2)
            
                send_email(email_dict[name[n]],"PASSWORD RESET CODE",msg)

                ncode = input("\nEnter the code sent to the registered email to reset the password : ")

                if ncode == code2:
                    npass = input("\nEnter the new password you want to set : ")
                    npassconfirm = input("Enter the password again for confirmation : ")

                    if npass == npassconfirm:

                        del store_pass[name[n]]
                        store_pass[name[n]] = npass
                        with open("pass.txt", "bw") as writefile:
                            store_pass = pickle.dump(store_pass, writefile, protocol=2)

                        print("\nYour new password has been saved successfully!!")
                        sleep(6)

                    else:
                        print("\nThe password entered is not matched the second time.\nSorry! your password has not been saved.")
                        sleep(6)

                else:
                    print("\nThe code entered by you is incorrect.\nSorry! Try again.")
                    sleep(6)

            else:
                msg = f"Hi {name[n].capitalize().split()[0]}.\n\nThis is to inform you that someone has entered the password of your password manager incorrect. The person has entered the password --> {password2}\nYour password manager has stopped. The pic of the person is in the next email. Please take any action."
                cam = cv2.VideoCapture(0)
                cv2.namedWindow("IMAGE")
                k = cv2.waitKey(1)
                ret, frame = cam.read()
                img_name = "opencv_frame.png"
                cv2.imwrite(img_name, frame)
                with open('opencv_frame.png',"rb") as ha:
                    data = ha.read()

                with open("email.txt", "br") as file2:
                    email_dict = pickle.load(file2)
            
                send_email(email_dict[name[n]],"PASSWORD MANAGER ALERT!",msg)
                attach_email(email_dict[name[n]],"PASSWORD MANAGER SUSPECIOUS PERSON PIC",data,"application","png","pic captured.png")

                cam.release()
                cv2.destroyAllWindows()

                print("\nWe think that you are not an authoriseed person. We are informing this to the owner. \nIf you think it is a mistake then we are sorry, please try re-running the program.")
                sleep(6)
    else:
        # msg = f"This is to inform you that somebody is trying to enter the password manager without authorisation.\n\nPlease take care of this.\n\nA picture of that person is sent to your email."

        cam = cv2.VideoCapture(0)
        cv2.namedWindow("IMAGE")
        k = cv2.waitKey(1)
        ret, frame = cam.read()
        img_name = "opencv_frame.png"
        cv2.imwrite(img_name, frame)
        with open('opencv_frame.png',"rb") as ha:
            data = ha.read()

        with open("email.txt", "br") as file2:
                email_dict = pickle.load(file2)

        for i in range(1,len(name)):
            msg = f"Hi {name[i].capitalize().split()[0]}.\n\nThis is to inform you that somebody is trying to enter the password manager without authorisation.\n\nPlease take care of this.\n\nA picture of that person is sent to your email."
            
            send_email(email_dict[name[i]],"PASSWORD MANAGER ALERT!",msg)
            attach_email(email_dict[name[i]],"PASSWORD MANAGER SUSPECIOUS PERSON PIC",data,"application","png","pic captured.png")
            sleep(6)

        cam.release()
        cv2.destroyAllWindows()
        
        print("\nWe think that you are not an authoriseed person. We are informing this to the owner. \nIf you think it is a mistake then we are sorry, please try re-running the program.")
        sleep(6)

main()