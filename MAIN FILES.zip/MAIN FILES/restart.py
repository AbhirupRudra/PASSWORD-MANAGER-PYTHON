import pickle
import os
import sys
from time import sleep

with open("name.txt", "br") as default4:
    n = pickle.load(default4)

for i in range(1,len(n)):
    
    try:
        if os.path.isfile("account\\"+(n[i].lower()+".txt")):
            os.remove("account\\"+(n[i].lower()+".txt"))
    except OSError:
        print("Error occured while deleting the files.")
        sleep(6)
        sys.exit("Stopping the program...")

n = [" "]
with open("name.txt", "bw") as default:
    n = pickle.dump(n, default, protocol=2)

m = {" ":" "}
with open("pass.txt", "bw") as default2:
    m = pickle.dump(m, default2, protocol=2)

m = {" ":" "}
with open("email.txt", "bw") as default3:
    m = pickle.dump(m, default3, protocol=2)

def delete_all_photos(path):
    try:
        files = os.listdir(path)
        for file in files:
            fpath = os.path.join(path, file)
            if os.path.isfile(fpath):
                os.remove(fpath)
    except OSError:
        print("Error occured while deleting the files.")
        sleep(6)
        sys.exit("Stopping the program...")

delete_all_photos("datasets")

try:
    if os.path.isfile("data\\Trainer.yml"):
        os.remove("data\\Trainer.yml")
except OSError:
    print("Error occured while deleting the files.")
    sleep(6)
    sys.exit("Stopping the program...")

try:
    if os.path.isfile("opencv_frame.png"):
        os.remove("opencv_frame.png")
except OSError:
    print("Error occured while deleting the files.")
    sleep(6)
    sys.exit("Stopping the program...")

print("PASSWORD MANAGER RESTARTED SUCCESSFULLY.")
sleep(6)