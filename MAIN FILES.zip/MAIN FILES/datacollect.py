import cv2 

video=cv2.VideoCapture(0)

facedetect = cv2.CascadeClassifier("data\\haarcascade_frontalface_default.xml")


def collect(ID):
    i = 0
    id = int(ID)
    count=0

    while True:
        ret,frame=video.read()
        gray=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = facedetect.detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            
            if count <= 100 and i%2 == 0:
                cv2.imwrite('datasets\\User.'+str(id)+"."+str(count)+".jpg", gray[y:y+h, x:x+w])
                count=count+1
            i+=1
            cv2.putText(frame, str(count), (50,50), cv2.FONT_HERSHEY_COMPLEX, 2, (50,50,255), 3)
            cv2.rectangle(frame, (x,y), (x+w, y+h), (50,50,255), 3)

        cv2.imshow("Frame",frame)

        k=cv2.waitKey(1)

        if count==100:
            break

    video.release()
    cv2.destroyAllWindows()
    print("Dataset Collection Done..................")

